/* Global defines for yab
   Do not change, unless you know what you are doing!

   (c) Jan Bungeroth 2006
   Artistic License.
*/
    
#define ZETA
#define BUILD_ZETA
#define BUILD_TABVIEW
#define BUILD_ZETATAB
// #define BUILD_HAIKUTAB
#define BUILD_COLUMNLISTVIEW
#define BUILD_CALENDAR
#define BUILD_FILEPANEL
#define BUILD_YABTEXT
#define BUILD_YABSTACKVIEW
#define BUILD_SPLITPANE
#define BUILD_URLVIEW
#define BUILD_SPINNER
#define BUILD_NCURSES
// #define BUILD_BUBBLEHELPER
#define BUILD_GAMESOUND
