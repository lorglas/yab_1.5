#ifndef YABFILEPANEL_H
#define YABFILEPANEL_H

class YabFilePanel
{
	public:
		BEntry *MyFilePanel(const char *name, const char *directory, const char* filename, int panelType);
};

#endif
